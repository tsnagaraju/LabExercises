<template>
    <div class="container">
        <h1>Product Details</h1>
        <div class="form">
            <form @submit.prevent="onSubmit()">
                <div class="row">
                    <label>Category: </label>
                    <select v-model="categoryName" @change="getProducts(categoryName)">
                        <option v-for="(l,i) in categories" :key='i'>{{l}}</option>
                    </select>
                </div>
                <div class="row">
                    <label>Product: </label>
                    <select v-model="productName" @change="getPrice(productName)">
                        <option v-for="(value,i) in selectedProducts" :key='i'>{{value}}</option>
                    </select>
                </div>
                <div class="row">
                    <label>Quantity: </label>
                    <input type="number" v-model = "quantity" @change="getFinalPrice(quantity)"/>
                </div>
                <div class="row">
                    <label>Total Price: </label>
                    <input type="text" v-model="finalPrice" readonly/><br><br>
                </div>
                <div class="btn">
                    <button type="submit">Submit</button>
                    <button type= "btn" @click="reset()">Clear</button>
                </div>
            </form>
        </div>
        <div class="result">
            <div v-if="finalData && finalData.length > 0">
                <div>
                    <div  v-for="(val,i) in finalData" :key='i' >
                    {{`Category: ${val.category}
                        Product: ${val.product}
                        Quantity: ${val.quantity}
                        FinalPrice: ${val.price}`
                    }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "Lab1",
    data() {
        return {
            categoryName: "",
            productName: "",
            productPrice: "",
            quantity: "",
            finalPrice: "",
            finalData:[],
            selectedProducts: [],
            relatedProducts: [],
            categories:[],
            products:[
             {
                id: "1",
                category: "electronics",
                name: "television",
                price: "20000"
             },
             {
                id: "2",
                category: "electronics",
                name: "laptop",
                price: "30000"
             },
             {
                id: "3",
                category: "electronics",
                name: "phone",
                price: "10000"
             },
             {
                id: "4",
                category: "groceries",
                name: "soap",
                price: "40"
             },
             {
                id: "5",
                category: "groceries",
                name: "powder",
                price: "90"
             }
          ],
        }
    },
    created() {
        this.getCategories();
    },
    methods:{
        getCategories(){
            let categories = this.products.map((product)=>{
                return product.category;
            })
            return this.categories = new Set (categories)
        },
        getProducts(categoryName){
            this.selectedProducts =this.relatedProducts = this.products.map((product) =>{
                if(product.category === categoryName){
                   return product.name;
                }
            });
        },
        getPrice(productName){
            this.products.map((product) => {
                if(product.name === productName){
                return this.productPrice = product.price;
           }
        });
        },
        getFinalPrice(qty){
            return this.finalPrice = qty * this.productPrice;
        },
        reset() {
            this.finalData = [];
            this.values = {};
            this.categoryName = '';
            this.productName = '';
            this.quantity = '';
            this.finalPrice = '';
        },
        onSubmit(){
            const values = {
                category: this.categoryName,
                product: this.productName,
                quantity: this.quantity,
                price: this.finalPrice
            };
            return this.finalData.push(values);
        }
    }
};
</script>

<style scoped>
    .form {
        border: 1px solid blue;
        width: 300px;
        margin: 0 auto;
        padding: 20px;
       
    }
    .result {
        width: 300px;
        margin: 20px auto;
    }
     .row {
            margin: 20px auto;
        }
    select {
        min-width : 50px;
    }
    button {
        margin : 0px 10px;
        width: 60px;
    }
</style>