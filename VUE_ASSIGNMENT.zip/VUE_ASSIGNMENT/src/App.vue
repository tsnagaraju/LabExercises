<template>
  <div id="app">
    <city />
    <br><br>
   <sortproduct />
   <br>
   <br>
   <product msg="hai"/>
   <skill msg="hello"/> 
  </div>
</template>

<script>
//import HelloWorld from "./components/HelloWorld.vue";
import city from "./components/city";
import sortproduct from "./components/sortproduct";
import product from "./components/product";
import skill from "./components/skill";

export default {
  name: "App",
  components: {
     product,
     skill,
     sortproduct,
    city
  }
};
</script>

<!--<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>-->
