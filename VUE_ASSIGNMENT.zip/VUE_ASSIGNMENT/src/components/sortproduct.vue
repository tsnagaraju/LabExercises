<template>
<div>
    <h2>Sorting Products</h2>
    <select id="option" @change="sort">
        <option  >High to Low</option>
        <option  >Low to High</option>
    </select>
    <br>
    <br>
    <select>
        <option v-for="(p,i) in newProduct" :key="i">{{p}}</option> 
    </select>
    <h3>--------------------------------------------</h3>
</div>
</template>
<script>
export default {
    data(){
        return {
           
        product:
        [
            {name:"laptop",price:40000},{name:"tv",price:20000},{name:"phone",price:3000},{name:"Tablet",price:45000}
        ],
        newProduct:[]

    
    }
    },
    methods:
    {
       sort()
       {    
           
            this.product.sort(function(a, b){
                
            return a.price-b.price})
            for(var i=0;i<this.product.length;i++)
                {
                    console.log(this.product[i].name)
                }
            this.newProduct=this.product;
            var x=document.getElementById("option").value;
            if(x=="High to Low"){
                this.newProduct.reverse()
            }
        

    
       
         
        //    { console.log(x);
        //        this.map=new TreeMap(this.map);

        //    }
       }
    }
}
</script>
<style scoped>

</style>