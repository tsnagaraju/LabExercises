<template>
<div>
    <h2>City and State Example</h2>
    <select  @change="cityList($event)">
        <option  v-for="(s,i) in state" :key="i" >{{s.stateName}}</option>
    </select>
    <br>
    <br>
    <select>
    <option v-for="(c,i) in newList" :key="i">{{c}}</option>
    </select> 
    <h3>------------------------------------</h3>
</div>
</template>
<script>
export default {
    data() {
        return{   
             //newList:[],
        //     id:0,
        state:
            [
            {stateName:"Tamil Nadu",cityNames:["Chennai","Trichy"]},
            {stateName:"Andhra Pradesh",cityNames:["Guntur","Vishakpatnam"]},
            {stateName:"Karnataka",cityNames:["Bangalore","Mysore"]},
            {stateName:"Maharastra",cityNames:["Mumbai","Pune"]},
            {stateName:"Kerala",cityNames:["Cochin","Trivandrum"]}
            ],
        newList:[],
        id:0


        }
    },
    methods:
    {
        cityList(event)
        { var sName=event.target.value;
            for(var i=0;i<this.state.length;i++)
            {
                if(this.state[i].stateName==sName)
                {
                    this.newList=this.state[i].cityNames;
                    break;
                }
            }

      //  this.newList=this.state
            // var x=document.getElementById("list").value;
            // console.log(x);
            // // if(x==TamilNadu)
            // {
            //     this.newList=this.state[0].cityNames;
            // }
            // else if(x==)

        }
    }
}
</script>