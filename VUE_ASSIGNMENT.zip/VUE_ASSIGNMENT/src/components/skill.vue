<template>
    <div>
        <h1>Skill Checkbox Example</h1>
        <br><br>
        <input type="text" v-model=task>
        <br>
        <br>
        <input type=checkbox v-model=final>
        <input  type="submit"  value="Add Task" @click="addSkill">
        <ul v-for="(s,i) in skillSet" :key="i" >
            <input type="checkbox"  name=box @change="storeIndex(i)" >{{s}}
        </ul>
       <button @click="removeSkill">Remove Task</button>
       

        <h3>--------------------------------</h3>
    </div>
    
</template>
<script>
export default {
    data (){
        return{
            skillSet:[],
            task:"",
            final:false,
            index:[],
            id:0
        }

    },
    methods:
    {
        addSkill()
        {
         this.skillSet.push(this.task);
         this.skillSet2=this.skillSet;
                 },
        removeSkill()
        {
          if(this.final==true)
          {
              this.skillSet.splice(0,this.skillSet.length)
          }
          else 
          { //alert(this.index)
            for(this.id=0;this.id<this.index.length;this.id++)
            {
                this.skillSet[this.index[this.id]]="#"
            }
            
            for(this.id=0;this.id<this.skillSet.length;this.id++)
            {
                if(this.skillSet[this.id]=="#")
                {
                    this.skillSet.splice(this.id,1);
                    this.id--;
                }
            }
            this.index=[];
         
            var items=document.getElementsByName("box");
            for(var i=0; i<items.length; i++){
					if(items[i].type=='checkbox')
                        items[i].checked=false;
            }
         }
        },
        storeIndex(i)
        {
            this.index.push(i);
        }
        
       
    }
}
</script>