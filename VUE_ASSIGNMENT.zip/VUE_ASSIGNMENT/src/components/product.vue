<template>
<div>
    
    <form @submit.prevent="calculate">
        <h2>Product Details</h2>
    <table border=1>
        <th colspan="2">Product Details</th>
        <tr>
            <td>Categories</td>
            <td>
                <select @change=onChange($event)><option v-for="(c,i) in catg" :key="i">{{c}}</option>
                </select>
                </td>
        </tr>
        <tr>
            <td>Product</td>
            <td>
                
            <select @click=changeItem($event)><option>----</option><option v-for="(p,i) in final_prod" :key="i">{{p}}</option></select></td>
        </tr>
        <tr>
            <td>Quantity</td>
            <td><input v-model=qty type="number"/></td>
        </tr>
        <tr>
            <td>Price</td>
            <td><input v-model=total_price type="number" readonly /></td>
        </tr>
        <tr>
          <td>  <input type=submit value=Submit></td>
          <td><input type=reset value=Clear></td>
          </tr>


    </table>
    </form>
    <h3>---------------------------------------------</h3>
</div>
    
</template>
<script>
export default {
    data(){
        return{
            prod1:["television","laptop","phone"],
            prod2:["soap","powder"],
            catg:["electronics","groceries"],
            selected_catg:"",
            selected_items:"",
            final_prod:[],
            price:0,
            total_price:0,
            qty:0
        }
    },
    methods:
    {
        onChange(event){
            console.log(event.target.value)
            this.selected_catg=event.target.value
            alert(this.selected_catg)
            if(this.selected_catg=='electronics')
            {
               this.final_prod=this.prod1;
            }
            else{
               this.final_prod=this.prod2;
            }
        },
        changeItem(event)
        {
            this.selected_items=event.target.value
            if(this.selected_items=="television")
            {
               this.price=20000;
            }
            else if(this.selected_items=="laptop")
            {
                this.price=30000
            }
            else if(this.selected_items=="phone")
            {
                this.price=10000
            }
            else if(this.selected_items=="soap")
            {
                this.price=40
            }
            else if(this.selected_items=="powder")
            {
               this.price=90
            }
        },
        calculate()
        {
            this.total_price=this.price*this.qty;
            alert(this.total_price)
        }

    }
    
}
</script>