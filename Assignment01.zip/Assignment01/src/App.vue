<template>
  <div id="app">
    
   
   <product msg="hai"/>
   <skill msg="hello"/>
  </div>
</template>

<script>
//import HelloWorld from "./components/HelloWorld.vue";
//import person  from "./components/person";
//import directive from "./components/directive";
import product from "./components/product";
import skill from "./components/skill";

export default {
  name: "App",
  components: {
    product,
    skill
  }
};
</script>

<!--<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>-->
