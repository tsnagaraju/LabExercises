export enum Products{
    "Electronics" = 'electronics',
    "Grocery" = 'grocery',
}